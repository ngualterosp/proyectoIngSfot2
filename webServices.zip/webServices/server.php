<?php 

include('nusoap.php'); 
$url = "http://localhost/proyectoSoft2/proyectoIngSfot2/webServices/server.php";



$server = new soap_server(); 
$server->configureWSDL("consulta", "urn:miservice"); 




if( ! isset( $HTTP_RAW_POST_DATA )) {
   $HTTP_RAW_POST_DATA = file_get_contents( 'php://input' );
}

function consulta($id) { 
  
   $conn = mysqli_connect("localhost","root", "","pruebaWS"); 

   $query = $conn->query("SELECT nombre FROM nomi WHERE id_nomi = '$id' "); 
   
  $arrayJugador =[];
   while($jugador = mysqli_fetch_array($query, MYSQLI_ASSOC)){

   	$arrayJugador[] = $jugador;

   }
   return json_encode($arrayJugador);
   }
   
 

$server->register("consulta", 
            array("id" => 'xsd:int'), 
            array("return" => 'xsd:string'), 
            "urn:miservice",
            "urn:miservice#consulta",
            "rpc",
            "encoded",
            "Darjugador por param");

            
$server->service($HTTP_RAW_POST_DATA);

?>