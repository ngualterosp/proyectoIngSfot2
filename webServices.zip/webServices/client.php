

<?php 

require "nusoap.php";
$url="http://localhost/proyectoSoft2/proyectoIngSfot2/webServices/server.php?wsdl";
$cliente = new nusoap_client($url);
$nombre = $cliente->call("consulta", array("id"=>2));
$nombre = json_decode($nombre);
print_r($nombre);
echo $nombre;

?> 
</body> 
</html> 